<?php 
require_once("model.php");
$exemplaires = getExemplaire();
require_once("vue.php");


?>