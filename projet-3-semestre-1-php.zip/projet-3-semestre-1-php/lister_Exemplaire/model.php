<?php  

function getExemplaire():array 
{
    $exemplaires = [
        ["id_exemplaire" => 1 , "date d'enregistrement" => "21/04/2017", "reference_id" => 1],
        ["id_exemplaire" => 2 , "date d'enregistrement" => "21/04/2020","reference_id" => 2],
        ["id_exemplaire" => 3 , "date d'enregistrement" => "21/04/2020","reference_id" => 2],
        ["id_exemplaire" => 4 , "date d'enregistrement" => "18/12/2013","reference_id" => 3],
        ["id_exemplaire" => 5 , "date d'enregistrement" => "18/12/2013","reference_id" => 3],
        ["id_exemplaire" => 6 , "date d'enregistrement" => "18/12/2022","reference_id" => 6],
        ["id_exemplaire" => 7 , "date d'enregistrement" => "21/04/1999","reference_id" => 7],
        ["id_exemplaire" => 8 , "date d'enregistrement" => "21/04/2022","reference_id" => 8]
    ];
    $exemplaire[] = $exemplaires;
    return $exemplaires;
}










?>