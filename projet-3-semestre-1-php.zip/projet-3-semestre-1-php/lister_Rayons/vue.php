<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/style.css">
    <title>lister des rayons</title>
</head>
<body>
    <div class="container">
        <h1>liste des rayons</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>NOM</th>
                <th>OUVRAGE_ID</th>
            </tr>

            <?php  foreach ($rayons as  $value): ?>
                <tr>
                    <th><?php  echo ($value["id"]); ?> </th>
                    <th><?php  echo ($value["nom"]); ?></th>
                    <th><?php  echo ($value["ouvrage_id"]); ?></th>
                </tr>
                <?php  endforeach ?>
        </table>
    </div>
</body>
</html>