<?php

require_once("model.php");

$rayons = getRayon();
require_once("vue.php");

?>