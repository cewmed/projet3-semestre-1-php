<?php
function getRayon():array
{
    $rayons = [
        ["id" =>1, "nom" => "developpement", "ouvrage_id" =>1],
        ["id" =>2, "nom" => "integration web", "ouvrage_id" =>2],
        ["id" =>3, "nom" => "sgbg", "ouvrage_id" =>3],
        ["id" =>4, "nom" => "bande dessiné", "ouvrage_id" =>4],
        ["id" =>5, "nom" => "developpement", "ouvrage_id" =>5],
        ["id" =>6, "nom" => "communication", "ouvrage_id" =>6],
        ["id" =>7, "nom" => "digitale-web", "ouvrage_id" =>7],
        ["id" =>8, "nom" => "histoire", "ouvrage_id" =>8]
    ];
    $rayon[] = $rayons;
    return $rayons;
    
}



?>