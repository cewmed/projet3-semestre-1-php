<?php
function getOuvrage():array
{
    $ouvrages = [
        ["id" => 1 , "titre" => "Apprendre php 8" , "date d'edition" => "21/04/2017" , "nom" => "wane", "prenom" => "Baila" , "profession" => "Developpeur" , "exemplaire d'ouvrage" => 17],
        ["id" => 2 , "titre" => "Apprendre Html" , "date d'edition" => "21/04/2020" , "nom" => "wane", "prenom" => "Baila" , "profession" => "Developpeur" , "exemplaire d'ouvrage" => 48 ],
        ["id" => 3 , "titre" => "SQL pour les nuls" , "date d'edition" => "18/12/2013" , "nom" => "kara", "prenom" => "Boubacar" , "profession" => "Enseignant", "exemplaire d'ouvrage" => 18 ],
        ["id" => 4 , "titre" => "Moi moche et mechants 3" , "date d'edition" => "11/12/2013" , "nom" => "giroud", "prenom" => "Frank" , "profession" => "designer" , "exemplaire d'ouvrage" => 50 ],
        ["id" => 5 , "titre" => "Flutter" , "date d'edition" => "21/04/2003" , "nom" => "ndaw", "prenom" => "Adama" , "profession" => "etudiant" , "exemplaire d'ouvrage" => 10 ],
        ["id" => 6 , "titre" => "Marketing" , "date d'edition" => "18/12/2022" , "nom" => "koué", "prenom" => "Brice" , "profession" => "responsable digitale" , "exemplaire d'ouvrage" => 14 ],
        ["id" => 7 , "titre" => "Web 3" , "date d'edition" => "21/04/1999" , "nom" => "nasdas", "prenom" => "Temeli" , "profession" => "cryptologue", "exemplaire d'ouvrage" => 8 ],
        ["id" => 8 , "titre" => "Sociologie" , "date d'edition" => "21/04/2022" , "nom" => "federro", "prenom" => "Toto" , "profession" => "docteur" , "exemplaire d'ouvrage" => 11 ]
    ];

    $ouvrage = $ouvrages;
    return $ouvrages;
}

?>