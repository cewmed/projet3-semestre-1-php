<?php

require_once("model.php");
$ouvrages = getOuvrage();
require_once("vue.php");



?>