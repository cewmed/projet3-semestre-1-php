<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./public/style.css">
    <title>lister les auteurs</title>
</head>
<body>
    <div class="container">
        <h1>liste des auteurs</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>PRENOM</th>
                <th>NOM</th>
                <th>PROFESSION</th>
            </tr>
            <?php foreach ($auteurs as  $valeurs) :?>
                <tr>
                <th><?php echo($valeurs["id"]);?></th>
                    <th><?php echo($valeurs["prenom"]); ?></th>
                    <th><?php echo($valeurs["nom"]);?></th>
                    <th><?php echo($valeurs["profession"]);?></th>
                </tr>
                <?php endforeach ?>
            
        </table>
    </div>
</body>
</html>