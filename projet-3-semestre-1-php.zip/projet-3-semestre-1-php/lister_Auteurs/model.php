<?php

function getAuteur():array
{
    $auteurs =[
        ["id" => 1 ,"nom" => "wane", "prenom" => "Baila" , "profession" => "Developpeur full-stack", "ouvrage_id" =>1],
        ["id" => 2,"nom" => "kara", "prenom" => "Boubacar" , "profession" => "Enseignant", "ouvrage_id" =>3],
        ["id" => 3 ,"nom" => "giroud", "prenom" => "frank" , "profession" => "designer", "ouvrage_id" =>4],
        ["id" => 4 ,"nom" => "ndaw", "prenom" => "Adama" , "profession" => "etudiant", "ouvrage_id" =>2],
        ["id" => 5 ,"nom" => "koué", "prenom" => "Brice" , "profession" => "responsable digitale", "ouvrage_id" =>6],
        ["id" => 6 ,"nom" => "nasdas", "prenom" => "Temeli" , "profession" => "cryptologue", "ouvrage_id" =>7],
        ["id" => 7 ,"nom" => "federro", "prenom" => "Toto julian" , "profession" => "docteur", "ouvrage_id" =>8],
        ["id" => 8 ,"nom" => "niang", "prenom" => "Aly Tall" , "profession" => "developpeur full-stack", "ouvrage_id" =>5]
    ];
    $auteur[] = $auteurs;
    return $auteurs;
}

?>