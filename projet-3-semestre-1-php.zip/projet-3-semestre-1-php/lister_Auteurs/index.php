<?php

require_once("model.php");

$auteurs = getAuteur();
require_once("vue.php");

?>